import argparse
import pandas as pd
import numpy as np
import os
from env_v0 import SpatialSpreadEnv
from tqdm import tqdm

parser = argparse.ArgumentParser()
parser.add_argument("--filename", type=str, default="Random_3.xlsx")
parser.add_argument("--ckpt_path", type=str, default="Seed_5.pt")
args = parser.parse_args()
os.makedirs("./result", exist_ok=True)
xlsx_path = os.path.join("./result", args.filename)

max_steps = 501
num_runs = 15
all_infection_rates = []
all_infected_counts = []

for run in tqdm(range(num_runs), desc="Running Simulations"):
    env = SpatialSpreadEnv(render_mode=None)
    obs, info = env.reset()

    run_infection_rates = []
    run_infected_counts = []
    for step in range(max_steps):
        #obs, reward, terminations, truncations, info = env.step({})
        actions = {agent: np.random.randint(0, 4) for agent in env.agents}
        obs, reward, terminations, truncations, info = env.step(actions)

        infection_status = env.infection_status
        infected_total = np.sum(infection_status)
        infection_rate = infected_total / len(infection_status)

        run_infected_counts.append(infected_total)
        run_infection_rates.append(infection_rate)
        if any(terminations.values()) or all(truncations.values()):
            break
    # env.close()
    final_step = step + 1
    if final_step < max_steps:
        pad_len = max_steps - final_step
        run_infected_counts += [run_infected_counts[-1]] * pad_len
        run_infection_rates += [run_infection_rates[-1]] * pad_len

    all_infected_counts.append(run_infected_counts)
    all_infection_rates.append(run_infection_rates)

avg_infected_counts = np.mean(all_infected_counts, axis=0)
avg_infection_rates = np.mean(all_infection_rates, axis=0)
std_dev_infection_rates = np.std(all_infection_rates, axis=0)
standard_error_infection_rates = std_dev_infection_rates / np.sqrt(num_runs)
one_sd = avg_infection_rates + standard_error_infection_rates
neg_one_sd = avg_infection_rates - standard_error_infection_rates
step_record = list(range(max_steps))

df = pd.DataFrame({
    "step": step_record,
    "infection_rate": avg_infection_rates.tolist(),
    "number_infected": avg_infected_counts.tolist(),
    "standard_error": standard_error_infection_rates.tolist(),
    "one_sd": one_sd.tolist(),
    "neg_one_sd": neg_one_sd.tolist()
})
df.to_excel(xlsx_path, index=False)