import functools
import random
from copy import copy
import numpy as np

import matplotlib.pyplot as plt
from matplotlib.animation import FFMpegWriter

class PolyUtility:
    def __init__(self, seek_para:int = 2, averse_para:int = 2, R_max: int = 100) -> None:
        if seek_para not in {2, 3, 4, 5}:
            raise ValueError(f"seek_para must be one of {{2, 3, 4, 5}}, got {seek_para}")
        if averse_para not in {2, 3, 4, 5}:
            raise ValueError(f"averse_para must be one of {{2, 3, 4, 5}}, got {averse_para}")
        #a = [1, 10, 100**(2/3), 100**(3/4), 100**(4/5)]
        #s = [1, 0.01, 0.0001, 0.000001, 0.00000001]
        self.averse_param = 100**((averse_para-1)/averse_para)
        self.averse_param2 = 1/100**(averse_para-1)
        self.seek_param = 1/100**(seek_para-1)
        self.seek_param2 = 100**((seek_para-1)/seek_para)
        self.seek_para = seek_para
        self.averse_para = averse_para
        if not isinstance(R_max, int):
            raise ValueError("R_max must be an integer.")
        self.R_max: int = R_max
        self.R_min: int = 0

    def calU(self, wealth: float, risk_type: int = 2) -> float:
        if risk_type == 0:
            beta = self.averse_param
            beta2 = self.averse_param2
            x = 1/self.averse_para
            x2 = self.averse_para
        elif risk_type == 1:
            beta = self.seek_param
            beta2 = self.seek_param2
            x = self.seek_para
            x2 = 1/self.seek_para
        elif risk_type == 2:
            return wealth
        else:
            raise ValueError("Invalid risk_type.")
        if wealth >= 0:
            return beta*wealth**x
        else:
            return -beta2*(-wealth)**x2

uu = PolyUtility()
u = np.vectorize(uu.calU)

class SpatialSpreadEnv:
    metadata={
        "name": "custom_environment_v0",
    }
    def __init__(self, render_mode=None, side_len:int = 232, numA:int = 300):
        self.num_agents = numA
        self.timestep = None
        self.render_mode = render_mode
        self.possible_agents = [f"agent_{i}" for i in range(numA)] #
        self.position = None
        self.carefulness = None
        self.mobility = None
        self.infection_status = None
        self.risk_types = None
        self.num_contact = None
        self.consecutive_no_social = None  
        self.consecutive_no_move = None
        
        self.side_len = side_len
        self.fig, self.ax = plt.subplots()
        self.scatter = None
        self.accumR = None
        self.i_dura = None
        self.flag = None
        self.flag2 = None
        self.social = None
        self.init_carefulness = None
        self.init_mobility = None

    def reset(self, seed=None, options=None):
        self.agents = copy(self.possible_agents)
        self.timestep = 0
        
        self.position = np.random.randint(0, self.side_len, size=(self.num_agents, 2)) 
        self.risk_types = np.array([i % 3 for i in range(self.num_agents)])
        self.carefulness = np.where(self.risk_types == 0, np.random.uniform(0.5, 1, self.num_agents),  
                   np.where(self.risk_types == 1, np.random.uniform(0, 0.5, self.num_agents),  
                   np.random.rand(self.num_agents))) 
        self.mobility = np.random.rand(self.num_agents)

        self.init_carefulness = self.carefulness.copy()
        self.init_mobility = self.mobility.copy()

        self.infection_status = np.zeros(self.num_agents, dtype=bool)
        self.infection_status[0] = True
        self.num_contact = np.zeros(self.num_agents, dtype=int) 
        self.consecutive_no_social = np.zeros(self.num_agents, dtype=int)
        self.consecutive_no_move = np.zeros(self.num_agents, dtype=int)
        self.accumR = {ag: 50 for ag in self.possible_agents}
        self.social = {ag: 0 for ag in self.possible_agents}
        self.i_dura = np.zeros(self.num_agents, dtype=int)
        self.flag = False
        self.flag2 = False

        observations = {}
        for i, agent in enumerate(self.agents):
            observations[agent] = self._get_observation(i)[0].flatten()
        infos = {a: {} for a in self.agents}
        return observations, infos



    
    def step(self):
        rewards = np.zeros(self.num_agents, dtype=float)
        terminations = {a: False for a in self.agents}
        truncations = {a: False for a in self.agents}
        mov_thres = 0.2
        current_Ir = np.mean(self.infection_status) * 100
        if current_Ir > 50:
            self.flag = True
            self.flag2 = True
        elif current_Ir < 30:
            self.flag = False
        thresholds = [1, 3, 2]
        for i, agent in enumerate(self.agents):
            distances = np.linalg.norm(self.position[i] - self.position, axis=1)
            nearby_mask = (distances <= 10) & (np.arange(self.num_agents) != i)
            infected_neighbors = np.sum(self.infection_status[nearby_mask])

            if infected_neighbors >= thresholds[self.risk_types[i]]:
                self.carefulness[i] = min(1.0, self.carefulness[i] + 0.02)
                self.mobility[i] = max(0.0, self.mobility[i] - 0.01)
            else:
                if self.carefulness[i] > self.init_carefulness[i]:
                    self.carefulness[i] = max(self.init_carefulness[i], self.carefulness[i] - 0.02)
                if self.mobility[i] < self.init_mobility[i]:
                    self.mobility[i] = min(self.init_mobility[i], self.mobility[i] + 0.01)
            ''' infected seekers (or all infected) slow down over time '''
            # if self.infection_status[i]:
                # self.mobility[i] = max(0.3, self.mobility[i] - 0.02)
            ''' reduce the mobility of averse '''
            # if self.risk_types[i] == 0 and current_Ir > 30 and self.flag:
                # self.mobility[i] = max(0.0, self.mobility[i] - 0.02) 
            if np.random.rand() < self.mobility[i] and self.mobility[i] >= mov_thres:
                self.consecutive_no_move[i] = 0
                dist = max(((self.mobility[i]+mov_thres)**3)*5, 0)
                direction = np.random.choice(4)
                if direction == 0:
                    self.position[i, 0] = (self.position[i, 0] - dist) % self.side_len
                elif direction == 1:
                    self.position[i, 0] = (self.position[i, 0] + dist) % self.side_len
                elif direction == 2:
                    self.position[i, 1] = (self.position[i, 1] - dist) % self.side_len
                else:
                    self.position[i, 1] = (self.position[i, 1] + dist) % self.side_len
            else:
                self.consecutive_no_move[i] += 1
            ''' punish high mobility '''
            if current_Ir > 30 and self.mobility[i] > 0.3 and self.flag2:
                 penalty = min(0, (-6/7) * self.mobility[i] - (2.4/7))
                 rewards[i] += self._convert_utility(penalty, self.agents[i], self.risk_types[i])
            ''' reward healthy agents '''
            if not self.infection_status[i] and self.carefulness[i] > 0.9 and self.flag:
                if current_Ir >= 40:
                    bonus = 1
                else:
                    bonus = 0.5
                rewards[i] += self._convert_utility(bonus, self.agents[i], self.risk_types[i])
        ''' termination and truncation '''
        if self.timestep > 501:
            truncations = {a: True for a in self.agents}
        observations = {agent: self._get_observation(i)[0].flatten() for i, agent in enumerate(self.agents)}
        infos = {a: {} for a in self.agents}
        ''' Social event multiplier '''
        socialR_S = self._rateToFactor(np.mean(self.infection_status) * 100)
        ''' social event or NOT '''
        socialR_I = 0.1
        for i, agent in enumerate(self.agents):
            if observations[agent][0] > 0: 
                nearby_agents = self._get_observation(i)[1]
                selected_neighbor = np.random.choice(nearby_agents)
                neigh_agent = self.agents[selected_neighbor]
                rand_num = np.random.rand()
                if i < selected_neighbor and rand_num>min(0.95, (self.carefulness[i]+self.carefulness[selected_neighbor])/2): # avoid double counting
                    # --- agent i’s local-density factor ---
                    df_i = 1
                    if self.infection_status[i] and observations[agent][2] >0.5: 
                        df_i = -1
                    # --- neighbor’s local-density factor ---
                    df_n = 1
                    if self.infection_status[selected_neighbor] and observations[neigh_agent][2]>0.5:
                        df_n = -1
                    if not self.flag:
                        base_i = socialR_I if self.infection_status[i] else socialR_S
                        rewards[i] += self._convert_utility(base_i * df_i,self.agents[i], self.risk_types[i]) 
                        self.social[self.agents[i]] += self._convert_utility(base_i * df_i,self.agents[i], self.risk_types[i]) 

                        base_n = socialR_I if self.infection_status[selected_neighbor] else socialR_S
                        rewards[selected_neighbor] += self._convert_utility(base_n * df_n, self.agents[selected_neighbor], self.risk_types[selected_neighbor])
                        self.social[self.agents[selected_neighbor]] += self._convert_utility(base_n * df_n, self.agents[selected_neighbor], self.risk_types[selected_neighbor])
                    
                    self.num_contact[i] += 1
                    self.num_contact[selected_neighbor] += 1
                    self.consecutive_no_social[i] = 0
                    self.consecutive_no_social[selected_neighbor] = 0
                    if self.infection_status[i] or self.infection_status[selected_neighbor]:
                        base_rate = 1.0
                        min_rate  = 0.0
                        avg_care = (self.carefulness[i] + self.carefulness[selected_neighbor]) / 2
                        infect_prob = min_rate + (1 - avg_care) * (base_rate-min_rate)
                        if np.random.rand() < infect_prob:
                            if not self.infection_status[i]:
                                self.infection_status[i] = True 
                            if not self.infection_status[selected_neighbor]:
                                self.infection_status[selected_neighbor] = True
                elif i < selected_neighbor:
                    self.consecutive_no_social[i] += 1
        
        ''' Persistent small punishment for the infected. '''
        diseaseCost = 0.0
        for i, agent in enumerate(self.agents):
            if self.infection_status[i] and self.risk_types[i] == 1 and observations[agent][2] >0.5: # seek in high risk region
                diseaseCost = -0.1
                rewards[i] += self._convert_utility(diseaseCost, self.agents[i], self.risk_types[i])
            elif self.risk_types[i] == 0 and self.infection_status[i]:
                diseaseCost = -0.5 if self.carefulness[i] < 0.8 else -0.2
                rewards[i] += self._convert_utility(diseaseCost, self.agents[i], self.risk_types[i])
        ''' Recovery Rate '''
        if current_Ir > 5:
            for i in range(self.num_agents):
                if self.infection_status[i]:
                    self.i_dura[i] += 1  
                    recovery_rate = min(0.2 * (self.i_dura[i] / 100), 0.2) 
                    if np.random.rand() < recovery_rate:
                        self.infection_status[i] = False
                        self.i_dura[i] = 0
            # infected_indices = [i for i in range(self.num_agents) if self.infection_status[i]]
            # num_to_treat = int(len(infected_indices) * 0.10)
            # selected_for_treatment = np.random.choice(infected_indices, num_to_treat, replace=False)
            # for i in selected_for_treatment:
            #     self.infection_status[i] = False
        ''' Equilibrium Condition '''
        current_Ir = np.mean(self.infection_status) * 100
        eq_reward = 0
        if any(terminations.values()) or all(truncations.values()):
            eq_reward = self._helperI(current_Ir)
            for i in range(self.num_agents):
                rewards[i] += self._convert_utility(eq_reward, self.agents[i], self.risk_types[i])
        ''' END '''
        rewards = {agent: rewards[i] for i, agent in enumerate(self.agents)}
        self.timestep += 1
        if any(terminations.values()) or all(truncations.values()):
            self.agents = []
        return observations, rewards, terminations, truncations, infos
    
    def render(self):
        if self.render_mode is None:
            return
        """Updates the plot in a static window for each timestep."""
        if self.scatter is None or self.timestep == 0:
            self.ax.clear()
            self.scatter = self.ax.scatter([], [], s=20, edgecolors='none') 
            self.ax.set_xlim(0, self.side_len)
            self.ax.set_ylim(0, self.side_len)
            self.ax.set_xticks([])  
            self.ax.set_yticks([]) 
            self.text = self.ax.figure.text(0.13, 0.08, '', fontsize=12, color='black')
            self.text_infection = self.ax.figure.text(0.13, 0.04, '', fontsize=12, color='black')
            self.text_carefulness = self.ax.figure.text(0.45, 0.04, '', fontsize=12, color='black')
            self.text_mobility = self.ax.figure.text(0.76, 0.04, '', fontsize=8, color='grey')
            if self.render_mode in ('human'):
                plt.ion()  
                plt.show()

        colors = np.where(self.infection_status, 'orangered', 'cornflowerblue')
        self.scatter.set_offsets(self.position) 
        self.scatter.set_facecolor(colors) #
        self.scatter.set_sizes(np.full(self.num_agents, 20))
        if self.timestep % 10 == 0:
            infection_rate = np.mean(self.infection_status) * 100
            infected_carefulness = np.mean(self.carefulness[self.infection_status]) if np.any(self.infection_status) else 0
            susceptible_carefulness = np.mean(self.carefulness[~self.infection_status]) if np.any(~self.infection_status) else 0
            
            self.text.set_text(f'Current Timestep: {self.timestep}')
            self.text_infection.set_text(f'Infection: {infection_rate:.1f}%')
            self.text_carefulness.set_text(f'I avg carefulness:  {infected_carefulness:.2f}\nS avg carefulness: {susceptible_carefulness:.2f}')
            low_mob   = np.mean(self.mobility[self.risk_types == 0])
            high_mob   = np.mean(self.mobility[self.risk_types == 1])
            med_mob  = np.mean(self.mobility[self.risk_types == 2])
            self.text_mobility.set_text(
                f'Averse mob:  {low_mob:.2f}\n'
                f'Neutral mob:  {med_mob:.2f}\n'
                f'Seek mob: {high_mob:.2f}'
            )
        if self.render_mode == 'mp4':
            if not hasattr(self, 'writer'):
                self.writer = FFMpegWriter(fps=15)
                self.writer.setup(self.fig, "output.mp4", dpi=100)
            self.writer.grab_frame()
        elif self.render_mode in ('human'):
            plt.pause(0.08)
    
    '''Helper methods'''
    def _convert_utility(self, reward:int = 1, agent: str = 'agent' , risk_type:int = 0):
        if agent not in self.accumR:
            raise ValueError(f"Agent {agent} not found in accumulated rewards!")
        old_value = self.accumR[agent]
        new_value = old_value + reward
        if new_value > 100 or new_value < 0:
            return 0
        self.accumR[agent] = new_value
        return u(new_value, risk_type = risk_type) - u(old_value, risk_type = risk_type)
        
    def _get_observation(self, agent_idx):
        distances = np.linalg.norm(self.position[agent_idx] - self.position, axis=1)
        nearby_agents = np.where(distances <= 10)[0] # 10公尺是否適合?
        nearby_agents = nearby_agents[nearby_agents != agent_idx]

        memory = np.zeros(43, dtype=float)
        memory[0] = len(nearby_agents)
        memory[1] = self.infection_status[agent_idx]

        infected_count = 0
        for j, neighbor_idx in enumerate(nearby_agents[:10]):  # At most 10 neighbors
            start_idx = 3 + j * 4 # what if no agent??
            memory[start_idx] = True
            memory[start_idx + 1] = self.num_contact[neighbor_idx]
            memory[start_idx + 2] = self.risk_types[neighbor_idx]
            memory[start_idx + 3] = self.carefulness[neighbor_idx] >= 0.5
            if self.infection_status[neighbor_idx]:
                infected_count += 1

        for j in range(len(nearby_agents), 10):
            start_idx = 3 + j * 4
            memory[start_idx] = False
            memory[start_idx + 1] = -1
            memory[start_idx + 2] = -1
            memory[start_idx + 3] = False
        memory[2] = infected_count / memory[0] if memory[0] >= 1 else 0.0
        return memory.astype(np.float32), nearby_agents

    def _rateToFactor(self, rate):
        if rate <= 30:
            reward_mul = 0.16
        elif rate <= 50:
            reward_mul = 0.1
        else:
            reward_mul = 0
        return reward_mul
    def _helperI(self, x):
        if x <= 25:
            return 10
        elif x >= 45:
            return 0
        else:
            return -0.5 * (x - 25) + 10